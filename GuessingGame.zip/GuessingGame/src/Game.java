import java.util.Scanner;

public class Game
{
    public static void main (String args[])
    {
    	
        int numberToGuess = (int)(Math.random() * 100) + 1;
        int numberOfTries = 0;
        try (Scanner input = new Scanner(System.in)) {
			System.out.print("I'm thinking of a number. Guess a value (1-100): ");
			int guessNumber = input.nextInt();

			boolean win = false;
			while (win == false)
			{

			     numberOfTries++;


			     if (guessNumber < numberToGuess) 
			     {
			         System.out.print("Too Low.  Guess again: ");
			         guessNumber = input.nextInt();
			     }
			     else if (guessNumber > numberToGuess) 
			     {
			         System.out.print("Too High.  Guess again: ");
			         guessNumber = input.nextInt();
			     } 
			     else
			     {
			         System.out.println("Correct!  You got it in " + numberOfTries + " tries.");
			         win = true;
			     }
			}
		}
    }
}